export {
	renderHexJSON as renderHexJSON,
	getGridForHexJSON as getGridForHexJSON
} from "./src/render";
